package Location_LDA;

public class Pair {

	/**
	 * @param args
	 */
	
	public int rating;
	public int item_id;
	

}
