package Location_LDA;

public class Event {

	/**
	 * @param args
	 */
	public String ids;
	public int id;
	public String location;
	public int loction_id;
	public String category;
	public int category_id;

}
